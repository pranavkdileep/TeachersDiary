<div class="py-6 px-6 text-center footer ">
          <p class="mb-0 fs-4">Developed By Amirthjoy AI,Ajradh TK,Albert C Dominic & Archana BU.&copy;  2025 Teachers' Dairy.</a></p>
        </div>
      </div>
    </div>
  </div>
  <script src="assets/libs/jquery/dist/jquery.min.js"></script>
  <script src="assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/sidebarmenu.js"></script>
  <script src="assets/js/app.min.js"></script>
  <script src="assets/libs/apexcharts/dist/apexcharts.min.js"></script>
  <script src="assets/libs/simplebar/dist/simplebar.js"></script>
  <script src="assets/js/dashboard.js"></script>
</body>
<style>
  .footer {
position: fixed;
left: 0;
bottom: 0;
width: 100%;
background-color: #e2e2e2;
color: black;
text-align: center;
}

.fixbottom {
position: fixed;
left: 0;
bottom: 0;
width: 100%;
color: black;
text-align: center;
}
</style>

</html>


